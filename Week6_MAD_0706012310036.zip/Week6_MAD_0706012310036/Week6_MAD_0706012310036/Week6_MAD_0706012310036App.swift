//
//  Week6_MAD_0706012310036App.swift
//  Week6_MAD_0706012310036
//
//  Created by student on 27/03/25.
//

import SwiftUI

@main
struct Week6_MAD_0706012310036App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
